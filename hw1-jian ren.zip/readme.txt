{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset0 Monaco;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720

\f0\fs30 \cf0 \expnd0\expndtw0\kerning0
HW1:\
\'a0\
\pard\pardeftab720

\f1\fs26 \cf0 \expnd0\expndtw0\kerning0
totaly document count:\'a0 503473\
text corpus running time: 2.20165 min\
\pard\pardeftab720

\f0\fs30 \cf0 \expnd0\expndtw0\kerning0
\'a0\
\'a0\
\pard\pardeftab720

\f1\fs26 \cf0 \expnd0\expndtw0\kerning0
totaly document count:\'a0 198362\
web corpus running time: 1.7995166666666667 min\
\
\
i use java 8. }